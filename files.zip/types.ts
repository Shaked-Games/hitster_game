/**
 * types.ts
 * Shared type definitions for the server.
 */

export interface Song {
  id: string;
  name: string;
  artist: string;
  year: number;
  spotifyLink: string;
}

export interface SongWithEmbed extends Song {
  spotifyEmbedUrl: string;
}

/** Raw row shape from the CSV parser */
export interface CsvSongRow {
  name: string;
  artist: string;
  year: string;
  spotify_link: string;
}
