/**
 * routes/songs.ts
 * REST endpoint for song data.
 *
 * GET /api/songs  →  { songs: SongWithEmbed[] }
 */

import { Router, Request, Response } from 'express';
import { loadSongs, extractSpotifyTrackId } from '../songService.js';
import type { SongWithEmbed } from '../types.js';

const router = Router();

function buildEmbedUrl(spotifyLink: string): string {
  const trackId = extractSpotifyTrackId(spotifyLink);
  if (!trackId) return '';
  return `https://open.spotify.com/embed/track/${trackId}?utm_source=generator`;
}

router.get('/', async (_req: Request, res: Response) => {
  try {
    const songs = await loadSongs();
    const songsWithEmbed: SongWithEmbed[] = songs.map((song) => ({
      ...song,
      spotifyEmbedUrl: buildEmbedUrl(song.spotifyLink),
    }));
    res.json({ songs: songsWithEmbed });
  } catch (err) {
    console.error('Failed to load songs:', err);
    res.status(500).json({ error: 'Failed to load songs' });
  }
});

export default router;
