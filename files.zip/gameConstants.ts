/**
 * gameConstants.ts
 * Single source of truth for all magic numbers and enumerated values.
 */

import type { PlayerPosition } from '../types';

export const MAX_PLAYERS = 4 as const;
export const WINNING_CARD_COUNT = 10 as const;

/** Clockwise order of player board positions (index matches player index). */
export const PLAYER_POSITIONS: readonly PlayerPosition[] = [
  'bottom',
  'left',
  'top',
  'right',
] as const;

/** CSS custom-property accent color for each player (indexed 0–3). */
export const PLAYER_COLORS: readonly string[] = [
  'var(--color-p1)', // Player 1 – pink/red
  'var(--color-p2)', // Player 2 – cyan
  'var(--color-p3)', // Player 3 – yellow
  'var(--color-p4)', // Player 4 – green
] as const;

export const PLAYER_DEFAULT_NAMES: readonly string[] = [
  'Player 1',
  'Player 2',
  'Player 3',
  'Player 4',
] as const;

/** All valid game phases. */
export const GAME_PHASE = {
  /** Player-count selection screen. */
  SETUP: 'setup',
  /** Current player's turn begins; waiting for Play button. */
  IDLE: 'idle',
  /** Spotify embed is visible; song is (or can be) playing. */
  PLAYING: 'playing',
  /** Player is choosing a timeline slot. */
  PLACING: 'placing',
  /** Year is revealed; result shown before advancing. */
  REVEALING: 'revealing',
  /** A player has reached WINNING_CARD_COUNT. */
  WON: 'won',
} as const;

/** Reducer action type strings. */
export const ACTION = {
  INITIALIZE_GAME:   'INITIALIZE_GAME',
  PLAY_SONG:         'PLAY_SONG',
  DONE_LISTENING:    'DONE_LISTENING',
  SELECT_PLACEMENT:  'SELECT_PLACEMENT',
  CONFIRM_PLACEMENT: 'CONFIRM_PLACEMENT',
  ADVANCE_TURN:      'ADVANCE_TURN',
} as const;
