/**
 * types.ts
 * All shared TypeScript types for the Hitster client.
 * Import from here rather than defining inline types in components.
 */

import type { GAME_PHASE } from './constants/gameConstants';

// ── Domain Types ───────────────────────────────────────────────────────────────

/** A song loaded from the server (includes the Spotify embed URL). */
export interface Song {
  id: string;
  name: string;
  artist: string;
  year: number;
  spotifyLink: string;
  spotifyEmbedUrl: string;
}

/** One player's full state. */
export interface Player {
  /** Index used as stable ID (0–3). */
  id: number;
  name: string;
  /** CSS color value, e.g. 'var(--color-p1)'. */
  color: string;
  /** Board position that determines rotation and grid placement. */
  position: PlayerPosition;
  /** Songs already correctly placed, sorted by year. */
  timeline: Song[];
}

/** The four sides of the game board, in clockwise order. */
export type PlayerPosition = 'bottom' | 'left' | 'top' | 'right';

// ── Game State ─────────────────────────────────────────────────────────────────

export type GamePhase = (typeof GAME_PHASE)[keyof typeof GAME_PHASE];

export interface GameState {
  phase: GamePhase;
  players: Player[];
  currentPlayerIndex: number;
  /** The song for the current turn (hidden year until reveal). */
  currentSong: Song | null;
  /** Slot index the active player clicked; null = none selected yet. */
  tentativePlacementIndex: number | null;
  /** Set during REVEALING phase. null in all other phases. */
  placementCorrect: boolean | null;
  /** Set when phase === WON. */
  winner: Player | null;
  usedSongIds: string[];
  allSongs: Song[];
}

// ── Actions ────────────────────────────────────────────────────────────────────

export interface GameActions {
  initializeGame: (playerCount: number, songs: Song[]) => void;
  playSong: () => void;
  doneListen: () => void;
  selectPlacement: (slotIndex: number) => void;
  confirmPlacement: () => void;
  advanceTurn: () => void;
}
