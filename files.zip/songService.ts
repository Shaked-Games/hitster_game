/**
 * songService.ts
 * Loads songs from the CSV file and provides song-related utilities.
 * Results are cached after the first load.
 */

import { readFile } from 'fs/promises';
import { parse } from 'csv-parse/sync';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { randomUUID } from 'crypto';
import type { Song, CsvSongRow } from './types.js';

const __dirname = dirname(fileURLToPath(import.meta.url));

const SONGS_CSV_PATH = join(__dirname, '..', 'songs_list.csv');

let cachedSongs: Song[] | null = null;

// ── Parsing ────────────────────────────────────────────────────────────────────

function parseSongRow(row: CsvSongRow): Song {
  return {
    id: randomUUID(),
    name: row.name?.trim() ?? '',
    artist: row.artist?.trim() ?? '',
    year: parseInt(row.year, 10),
    spotifyLink: row.spotify_link?.trim() ?? '',
  };
}

function isValidSong(song: Song): boolean {
  return (
    song.name.length > 0 &&
    song.artist.length > 0 &&
    !isNaN(song.year) &&
    song.year > 1900 &&
    song.spotifyLink.length > 0
  );
}

// ── Public API ─────────────────────────────────────────────────────────────────

/**
 * Loads and returns all valid songs from the CSV.
 * Caches the result after the first call.
 */
export async function loadSongs(): Promise<Song[]> {
  if (cachedSongs) return cachedSongs;

  const rawCsv = await readFile(SONGS_CSV_PATH, 'utf-8');
  const rows: CsvSongRow[] = parse(rawCsv, {
    columns: true,
    skip_empty_lines: true,
    trim: true,
  });

  cachedSongs = rows.map(parseSongRow).filter(isValidSong);
  return cachedSongs;
}

/**
 * Extracts the Spotify track ID from a full Spotify track URL.
 * Handles: https://open.spotify.com/track/TRACK_ID
 *          https://open.spotify.com/intl-XX/track/TRACK_ID
 */
export function extractSpotifyTrackId(spotifyUrl: string): string | null {
  const match = spotifyUrl.match(/track\/([a-zA-Z0-9]+)/);
  return match ? match[1] : null;
}
