/**
 * CenterControl.tsx
 * The command center of the game board.
 *
 * Renders a different view per game phase:
 *   IDLE      – player name badge + Play button
 *   PLAYING   – Spotify embed iframe + "Done Listening" button
 *   PLACING   – instructions + "Lock In" button (enabled after a slot is chosen)
 *   REVEALING – correct/wrong result + year reveal + "Next Player" button
 */

import type { Player, Song } from '../../types';
import { GAME_PHASE } from '../../constants/gameConstants';
import styles from './CenterControl.module.css';

interface Props {
  phase: string;
  currentPlayer: Player;
  currentSong: Song | null;
  tentativePlacementIndex: number | null;
  placementCorrect: boolean | null;
  onPlay: () => void;
  onDoneListening: () => void;
  onConfirmPlacement: () => void;
  onNextTurn: () => void;
}

export default function CenterControl({
  phase,
  currentPlayer,
  currentSong,
  tentativePlacementIndex,
  placementCorrect,
  onPlay,
  onDoneListening,
  onConfirmPlacement,
  onNextTurn,
}: Props) {
  return (
    <div
      className={styles.center}
      style={{ '--player-color': currentPlayer.color } as React.CSSProperties}
    >
      {phase === GAME_PHASE.IDLE && (
        <IdleView
          currentPlayer={currentPlayer}
          onPlay={onPlay}
        />
      )}

      {phase === GAME_PHASE.PLAYING && currentSong && (
        <PlayingView
          currentSong={currentSong}
          onDoneListening={onDoneListening}
        />
      )}

      {phase === GAME_PHASE.PLACING && (
        <PlacingView
          currentPlayer={currentPlayer}
          hasSelection={tentativePlacementIndex !== null}
          onConfirmPlacement={onConfirmPlacement}
        />
      )}

      {phase === GAME_PHASE.REVEALING && (
        <RevealingView
          placementCorrect={placementCorrect}
          currentSong={currentSong}
          onNextTurn={onNextTurn}
        />
      )}
    </div>
  );
}

// ── Sub-views ─────────────────────────────────────────────────────────────────

interface IdleViewProps {
  currentPlayer: Player;
  onPlay: () => void;
}
function IdleView({ currentPlayer, onPlay }: IdleViewProps) {
  return (
    <div className={styles.idleView}>
      <div className={styles.turnBadge} style={{ background: currentPlayer.color }}>
        {currentPlayer.name}'s Turn
      </div>
      <p className={styles.songHint}>A mystery song awaits…</p>
      <button className={styles.playButton} onClick={onPlay}>
        <PlayIcon />
        <span>PLAY</span>
      </button>
      <p className={styles.instruction}>
        Press play to hear the song, then place it on your timeline
      </p>
    </div>
  );
}

interface PlayingViewProps {
  currentSong: Song;
  onDoneListening: () => void;
}
function PlayingView({ currentSong, onDoneListening }: PlayingViewProps) {
  return (
    <div className={styles.playingView}>
      <div className={styles.embedWrapper}>
        <iframe
          src={currentSong.spotifyEmbedUrl}
          width="100%"
          height="80"
          frameBorder="0"
          allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
          loading="lazy"
          title={`${currentSong.name} by ${currentSong.artist}`}
        />
      </div>
      <p className={styles.instruction}>
        Listen carefully, then click when you're ready to place it.
      </p>
      <button className={styles.doneButton} onClick={onDoneListening}>
        Done Listening →
      </button>
    </div>
  );
}

interface PlacingViewProps {
  currentPlayer: Player;
  hasSelection: boolean;
  onConfirmPlacement: () => void;
}
function PlacingView({ currentPlayer, hasSelection, onConfirmPlacement }: PlacingViewProps) {
  return (
    <div className={styles.placingView}>
      <p className={styles.placingTitle}>Place the song!</p>
      <p className={styles.instruction}>
        {hasSelection
          ? 'Happy with that spot? Lock it in!'
          : `${currentPlayer.name}: tap a slot on your timeline`}
      </p>
      <button
        className={styles.lockButton}
        onClick={onConfirmPlacement}
        disabled={!hasSelection}
      >
        🔒 Lock In
      </button>
    </div>
  );
}

interface RevealingViewProps {
  placementCorrect: boolean | null;
  currentSong: Song | null;
  onNextTurn: () => void;
}
function RevealingView({ placementCorrect, currentSong, onNextTurn }: RevealingViewProps) {
  return (
    <div className={styles.revealingView}>
      {placementCorrect === true && (
        <div className={`${styles.resultBanner} ${styles.resultCorrect}`}>
          <span className={styles.resultIcon}>✓</span>
          <span className={styles.resultText}>Correct!</span>
          {currentSong && (
            <span className={styles.resultYear}>{currentSong.year}</span>
          )}
        </div>
      )}
      {placementCorrect === false && (
        <div className={`${styles.resultBanner} ${styles.resultWrong}`}>
          <span className={styles.resultIcon}>✗</span>
          <span className={styles.resultText}>Not quite!</span>
          {currentSong && (
            <span className={styles.resultYear}>{currentSong.year}</span>
          )}
        </div>
      )}
      <button className={styles.nextButton} onClick={onNextTurn}>
        Next Player →
      </button>
    </div>
  );
}

function PlayIcon() {
  return (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="currentColor" aria-hidden>
      <path d="M8 5.14v14l11-7-11-7z" />
    </svg>
  );
}
